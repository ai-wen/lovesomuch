﻿// sm234.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>

extern "C"{
    #include "SM3.h"
    #include "sm2.h"
    #include "SM4.h"
    #include "ZUC.h"
}
//x86
//copy mirdef.h32 mirdef.h
//copy mrmuldv.c32 mrmuldv.c


//x86_64
//copy mirdef.w64 mirdef.h
//copy mrmuldv.w64 mrmuldv.c

int main()
{
    int ret = 0;
    ret = SM2_ENC_SelfTest();
    if (0 == ret)
        printf("sm2 en ok\n");
    else
        printf("sm2 en err\n");

    ret = SM2_KeyEX_SelfTest();
    if (0 == ret)
        printf("sm2 ex ok\n");
    else
        printf("sm2 ex err\n");

    ret = SM2_SelfCheck();
    if (0 == ret)
        printf("sm2 sv ok\n");
    else
        printf("sm2 sv err\n");

    ret = SM4_SelfCheck();    
    if (0 == ret)
        printf("sm4 ok\n");
    else
        printf("sm4 err\n");


    ret = ZUC_SelfCheck();
    if (0 == ret)
        printf("zuc ok\n");
    else
        printf("zuc err\n");


    ret = SM3_SelfTest();
    if (0 == ret)
        printf("sm3 ok\n");
    else
        printf("sm3 err\n");

    return 0;
}

